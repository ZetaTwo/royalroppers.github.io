#! /usr/bin/env python3
from Crypto.PublicKey import RSA
key = RSA.generate(4096, e=5)
flag = "REDACTED"
m = int.from_bytes(flag.encode(), 'big')
c = pow(m, key.e, key.n)
with open("babyrsa.txt", "w") as f:
    f.write("n = {}".format(key.n) + "\n")
    f.write("e = {}".format(key.e) + "\n")
    f.write("c = {}".format(c))
