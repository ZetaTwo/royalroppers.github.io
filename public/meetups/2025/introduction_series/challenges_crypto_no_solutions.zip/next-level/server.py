import socket
from Crypto.Util import number

HOST = '127.0.0.1'
PORT = 42069

def nextprime(n):
	p = n
	while True:
		if number.isPrime(p := p+1): return p

def calc_chall():
    p = number.getPrime(512)
    q = nextprime(p)
    r = nextprime(q)
    n = p*q*r
    e = 0x10001
    flag = int.from_bytes(open('flag.txt','r').read().encode())
    c = pow(flag,e,n)

    return n,c

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:

    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    s.bind((HOST, PORT))
    s.listen()
    print(f"Server listening on {HOST}:{PORT}")

    while True:
        conn, addr = s.accept()
        with conn:
            print(f"Connected by {addr}")
            n,c = calc_chall()
            message_1 = b"n = " + str(n).encode() + b"\n"
            message_2 = b"c = " + str(c).encode() + b"\n"
            print(message_1)
            print(message_2)
            conn.sendall(message_1)
            conn.sendall(message_2)
