from Crypto.Util.number import bytes_to_long, getPrime

flag = b"REDACTED"

pt = bytes_to_long(flag)

p = getPrime(1024)
q = getPrime(1024)
n = p*q

e_1 = getPrime(16)
e_2 = getPrime(16)

ct_1 = pow(pt, e_1, n)
ct_2 = pow(pt, e_2, n)

with open("big_e.txt", "w") as f:
    f.write("n = " + str(n) + "\n")
    f.write("e_1 = " + str(e_1) + "\n")
    f.write("e_2 = " + str(e_2) + "\n")
    f.write("ct_1 = " + str(ct_1) + "\n")
    f.write("ct_2 = " + str(ct_2) + "\n")