from pwn import *
from Crypto.Util import number
import sympy

def nextprime(n):
    p = n
    while True:
        if number.isPrime(p := p+1): return p

def priorprime(n):
    p = n
    while True:
        if number.isPrime(p := p-1): return p

e = 0x10001
found = False

r = remote("127.0.0.1", 42069)

# Retrieve n and c from the server
n = int(r.recvline().rstrip().split(b"n = ")[1])
c = int(r.recvline().rstrip().split(b"c = ")[1])

# Take cube root from the received n
cube_root = sympy.integer_nthroot(n,3)

# Get prime factors of n
possible_q = priorprime(cube_root[0])
possible_r = nextprime(possible_q)
possible_p = priorprime(possible_q) 
possible_n = possible_p * possible_q * possible_r

# Check if the right factors of n were found
if (possible_n - n == 0):
    print("Found prime factors of n!")
    print("p:",possible_p)
    print("q:",possible_q)
    print("r:",possible_r)
    found = True

# If right factors of n haven't been found go on
while found != True:

    possible_q = nextprime(possible_q)
    possible_p = priorprime(possible_q) 
    possible_r = nextprime(possible_q)

    possible_n = possible_p * possible_q * possible_r

    if (possible_n == n):
        print("Found prime factors of n!")
        print("p:",possible_p)
        print("q:",possible_q)
        print("r:",possible_r)
        break

# Calculate the private key d
phi = (possible_p - 1)*(possible_q - 1)*(possible_r - 1)
d = sympy.mod_inverse(e, phi)

print("\nPrivate key d is:",d,"\n")

# Decrypt the ciphertext and get the flag
plaintext = pow(c,d,n)
flag = plaintext.to_bytes((plaintext.bit_length() + 7) // 8, 'big')
flag = flag.decode("utf-8",errors="ignore")

print("Flag is:",flag)

r.close()
