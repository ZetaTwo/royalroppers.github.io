from pwn import remote

# Blocks in ECB always decrypt to the same block, so just split and decrypt

flag_hex = input()
flag_first = flag_hex[:96]+32*"0"
flag_second = flag_hex[-32:]+96*"0"

print(flag_first)
print(flag_second)

# HOST = 'chall.lac.tf'
# PORT = 31180

# io = remote(HOST, PORT)

# for i in range(3):
#     line = io.recvline().decode().strip()
#     if (i == 1):
#         flag_hex = line
# io.recv().decode().strip()

# io.sendline(flag_hex[:96]+32*"0")
# first,trash = io.recv().decode().strip().split("\n")

# io.sendline(flag_hex[-32:]+96*"0")
# second,trash = io.recv().decode().strip().split("\n")

# print(first)
# print(second)

# io.close()
