import angr
import claripy

# declare a symbolic bitvector
# inp = claripy.BVS('inp', 8*0x20)

p = angr.Project('...')

init_st = p.factory.entry_state()
# init_st = p.factory.call_state(addr=0x31337)

sm = p.factory.simgr(init_st)

# this is usually a lot faster
sm.use_technique(angr.exploration_techniques.DFS())

# find and avoid can be addresses (integers) or functions
# which accepts a state and returns a boolean
sm.explore(find=..., avoid=...)
st = sm.found[0]

# solve for value of some bitvector and cast to bytes
# print(st.solver.eval(..., bytes))

# add an assertion to the solver
# st.solver.add(...)

# dump stdin
print(st.posix.dumps(0))