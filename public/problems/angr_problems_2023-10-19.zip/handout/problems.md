# Roughly sorted in difficulty, ascending
 - Durins Dörrar (the example)
 - witchpass
 - the-all-seeing-eye
 - witch_king_of_angmar
 - bishbashbosh
 - fairlight
 - unbreakable (flag prefix is `CTF{`, this is needed)
 - double-protection