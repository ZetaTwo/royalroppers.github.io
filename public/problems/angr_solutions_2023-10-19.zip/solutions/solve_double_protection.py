import angr
import claripy

p = angr.Project('../handout/double-protection',
    main_opts={'base_addr': 0}
)

pass1 = claripy.BVS('pass1', 8*31)
pass2 = claripy.BVS('pass1', 8*31)

@p.hook(0x9c7, length=5)
def add_pass1(st):
    st.memory.store(st.regs.rsi, claripy.Concat(pass1, claripy.BVV(b'\0')))

@p.hook(0x9f0, length=5)
def add_pass2(st):
    st.memory.store(st.regs.rsi, claripy.Concat(pass2, claripy.BVV(b'\0')))

init_st = p.factory.entry_state(add_options={
    angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,
    angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS,
    *angr.options.unicorn
})

sm = p.factory.simulation_manager(init_st)
sm.use_technique(angr.exploration_techniques.DFS())

find = lambda st: b'SSM' in st.posix.dumps(1)
sm.explore(find=find, step_func=lambda sm:print(sm.active))
st = sm.found[0]
print(f'pass1: {st.solver.eval(pass1, bytes)}')
print(f'pass2: {st.solver.eval(pass2, bytes)}')
print(st.posix.dumps(1))