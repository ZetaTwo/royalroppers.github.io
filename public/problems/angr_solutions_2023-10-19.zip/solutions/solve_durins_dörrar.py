import angr

p = angr.Project('../handout/durins_dörrar', main_opts={
    'base_addr': 0x0
})

init_st = p.factory.call_state(0x11c9, add_options={
    angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,
    angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS
})
sm = p.factory.simulation_manager(init_st)
sm.explore(find=0x1279, avoid=0x1287)
print(sm.found[0].posix.dumps(0).decode())