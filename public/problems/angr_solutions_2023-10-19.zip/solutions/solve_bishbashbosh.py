import angr
import claripy

p = angr.Project('../handout/bishbashbosh', main_opts={'base_addr': 0})

@p.hook(0x963)
def print_status(st):
    print(st.solver.eval(inp, bytes).rstrip(b'\0'))

inp = claripy.BVS('inp', 8*0x30)
init_st = p.factory.entry_state(
    args=['./bishbashbosh', inp],
    add_options={
        angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,
        angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS,
        *angr.options.unicorn
    })
    
sm = p.factory.simulation_manager(init_st)
sm.use_technique(angr.exploration_techniques.DFS())
sm.explore(avoid=0x957)