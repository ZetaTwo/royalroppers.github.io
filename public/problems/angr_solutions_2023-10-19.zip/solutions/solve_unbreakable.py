import angr, claripy

p = angr.Project('../handout/unbreakable')

inp = claripy.BVS('inp', 8*0x43)
init_st = p.factory.entry_state(
    args=['./unbreakable', inp],
    add_options={
        angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,
        angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS,
        *angr.options.unicorn
})

chars = inp.chop(8)
for ch in chars[:50]:
    init_st.solver.add(ch != 0)

for i, v in enumerate(b'CTF{'):
    init_st.solver.add(chars[i] == v)

sm = p.factory.simulation_manager(init_st)
sm.use_technique(angr.exploration_techniques.DFS())
sm.explore(find=0x400839, avoid=0x400850, step_func=print)
print(sm.found[0].solver.eval(inp, bytes))