import angr
import claripy

p = angr.Project('../handout/double-protection',
    main_opts={'base_addr': 0}
)

init_st = p.factory.entry_state(add_options={
    angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,
    angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS,
    *angr.options.unicorn
})

sm = p.factory.simulation_manager(init_st)
sm.use_technique(angr.exploration_techniques.DFS())

find = lambda st: b'SSM' in st.posix.dumps(1)
sm.explore(find=find, step_func=lambda sm:print(sm.active))
st = sm.found[0]
print(st.posix.dumps(1))