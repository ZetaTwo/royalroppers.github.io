import angr
import claripy

p = angr.Project('../handout/fairlight')

inp = claripy.BVS('inp', 8*0xf)
init_st = p.factory.entry_state(
    args=['./fairlight', inp],
    add_options={
        angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,
        angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS,
        *angr.options.unicorn
})
for i, ch in enumerate(inp.chop(8)):
    if i == 0xe: init_st.solver.add(ch == 0)
    else: init_st.solver.add(ch != 0)

sm = p.factory.simulation_manager(init_st)
sm.explore(find=0x401a5a, avoid=0x40074d, step_func=print)
st = sm.found[0]
print(st.solver.eval(inp, bytes))