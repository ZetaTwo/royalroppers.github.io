import angr

p = angr.Project('../handout/the-all-seeing-eye')

init_st = p.factory.entry_state(
    # this is not strictly needed but speed things up by a ton
    add_options=angr.options.unicorn
)
sm = p.factory.simulation_manager(init_st)
sm.use_technique(angr.exploration_techniques.DFS())

find = lambda st: b'Good' in st.posix.dumps(1)
avoid = lambda st: b'Bad' in st.posix.dumps(1)
sm.explore(find=find, avoid=avoid)
st = sm.found[0]
print(st.posix.dumps(0).decode())