import angr
p = angr.Project('../handout/witchpass')

init_st = p.factory.entry_state()
sm = p.factory.simulation_manager(init_st)

sm.explore(
    find=lambda st: b'Welcome' in st.posix.dumps(1),
    avoid=lambda st: b'incorrect' in st.posix.dumps(1))
print(sm.found[0].posix.dumps(0).decode())