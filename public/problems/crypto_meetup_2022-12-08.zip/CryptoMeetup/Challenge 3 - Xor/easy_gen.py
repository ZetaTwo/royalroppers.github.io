from Crypto.Util.number import bytes_to_long, long_to_bytes
import random

with open("flag.txt", "r") as f: 
    flag = bytes_to_long(f.readline().encode())

key1 = random.randint(flag/2, flag*2)
key2 = random.randint(flag/2, flag*2)
key3 = random.randint(flag/2, flag*2)

a = key1
b = key2 ^ key1
c = key2 ^ key3
d = flag ^ key1 ^ key2 ^ key3

print(f"a = {a}")
print(f"b = {b}")
print(f"c = {c}")
print(f"d = {d}")